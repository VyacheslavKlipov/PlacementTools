<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Objekte nach links ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Objekte nach rechts ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Objekte nach vorne ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Objekte auf den Rücken ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Objekte nach unten ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Objekte nach oben ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Objekte zur Mitte der x-Achse ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Objekte zur Mitte der y-Achse ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Objekte zur Mitte der z-Achse ausrichten</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Positioniert Objekte rechts vom zuletzt ausgewählten Objekt</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Positioniert Objekte links vom zuletzt ausgewählten Objekt</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Positioniert Objekte hinter dem zuletzt ausgewählten Objekt</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Positioniert Objekte an der Vorderseite des zuletzt ausgewählten Objekts</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Positioniert Objekte zum Überlaufen des zuletzt ausgewählten Objekts</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Positioniert Objekte am Ende des zuletzt ausgewählten Objekts</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Zentriert Objekte zwischen den letzten beiden ausgewählten Objekten entlang der x-Achse</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Zentriert Objekte zwischen den letzten beiden ausgewählten Objekten entlang der y-Achse</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Zentriert Objekte zwischen den letzten beiden ausgewählten Objekten entlang der z-Achse</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Bewegen</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Drehung</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Standard</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Werkzeuge</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Bewegt die ausgewählten Objekte um eine Distanz von dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Bewegt die ausgewählten Objekte um eine Distanz von dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Bewegt die ausgewählten Objekte um eine Distanz von dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Punkt-zu-Punkt-Werkzeug. Verschiebt das vorletzte ausgewählte Objekt auf das zuletzt ausgewählte Objekt, indem die ausgewählten Punkte auf diese Objekte ausgerichtet werden. Andere ausgewählte Objekte folgen dem gleichen Pfad wie das vorletzte Objekt. Wenn eine Kante anstelle eines Punktes ausgewählt wird, wird die Mitte der Kante verwendet. Wenn eine Fläche ausgewählt ist, wird die geometrische Mitte genommen.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Punkt-zu-Punkt-Werkzeug. Bewegt sich nur auf die x-Achse</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Punkt-zu-Punkt-Werkzeug. Bewegt sich nur auf die y-Achse</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Punkt-zu-Punkt-Werkzeug. Bewegt sich nur auf die z-Achse</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Standard Transformationsbefehl</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Dreht Objekte 90 Grad entlang der x-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Dreht Objekte 90 Grad entlang der y-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Dreht Objekte 90 Grad entlang der z-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Dreht Objekte -90 Grad entlang der x-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Dreht Objekte -90 Grad entlang der y-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Dreht Objekte -90 Grad entlang der z-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Dreht Objekte um r Grad entlang der x-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Dreht Objekte um r Grad entlang der y-Achse</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Dreht Objekte um r Grad entlang der z-Achse</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Testobjekte erstellen</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Fordern Sie Informationen über das ausgewählte Element an. Wenn eine Kante ausgewählt ist, wird ihre Länge zurückgegeben, wenn ein Kreis seinen Durchmesser hat wenn ein Punkt, dann seine Koordinaten, wenn ein Gesicht, dann seine Dimensionen.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>Länge </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Durchmesser: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Abmessungen: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>nichts ausgewählt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Mit Gruppen</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Wenn mindestens ein Objekt einer Gruppe ausgewählt ist, werden alle Werkzeuge dieser Werkbank auf die gesamte Gruppe angewendet. Wenn sich alle ausgewählten Objekte innerhalb derselben Gruppe befinden, werden alle Werkzeuge dieser Werkbank nur auf die ausgewählten Objekte angewendet. Gruppen sind Objekte Part, Linkgruppe, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Nur lokal</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Alle Werkzeuge dieser Werkbank werden lokal auf Objekte angewendet, unabhängig davon, ob sie zu Gruppen gehören. Gruppen sind Objekte Bauteile, Linkgruppe usw.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Lokal/Gruppe</translation>
    </message>
  </context>
</TS>
