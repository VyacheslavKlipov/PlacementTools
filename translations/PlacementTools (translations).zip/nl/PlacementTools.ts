<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Lijnt objecten uit aan de linkerkant</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Lijnt objecten uit naar rechts</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Lijnt objecten uit op de voorkant</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Lijnt objecten uit op de rug</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Lijnt objecten uit op de bodem</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Lijnt objecten uit op de top</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Lijnt objecten uit op het midden van de x-as</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Lijnt objecten uit op het midden van de y-as</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Lijnt objecten uit op het midden van de z-as</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Posities objecten aan de rechterkant van het laatst geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Posities objecten links van het laatste geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Posities objecten achter het laatste geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Posities objecten aan de voorkant van het laatst geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Posities objecten over de laatste geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Posities objecten onder het laatste geselecteerde object</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Plaats objecten tussen de laatste twee geselecteerde objecten langs de x-as</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Plaats objecten tussen de laatste twee geselecteerde objecten langs de y-as</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Plaats objecten tussen de laatste twee geselecteerde objecten langs de z-as</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Verplaatsen</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Rotatie</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Standaardinstelling</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Hulpmiddelen</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Verplaatst de geselecteerde objecten met een afstand van dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Verplaatst de geselecteerde objecten met een afstand van dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Verplaatst de geselecteerde objecten met een afstand van dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Punt om de tool te markeren. Verplaatst het voorlaatste geselecteerde object naar het laatste, uitlijnt de geselecteerde punten op deze objecten. Andere geselecteerde objecten zullen hetzelfde pad volgen als het voorlaatste schema. Als een rand is geselecteerd in plaats van een punt, dan wordt het midden van de rand genomen. Als een oppervlak is geselecteerd, wordt zijn geometrisch centrum genomen.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Point to point tool. Beweegt alleen op de x-as</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Point to point tool. Beweegt alleen op de y-as</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Point to point tool. Beweegt alleen op de z-as</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Standart Transformatie opdracht</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Roteert objecten 90 graden langs de x-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Roteert objecten 90 graden langs de y-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Roteert objecten 90 graden langs de z-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Roteert objecten -90 graden langs de x-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Roteert objecten -90 graden langs de y-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Roteert objecten -90 graden langs de z-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Roteert objecten per r graden langs de x-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Roteert objecten per r graden langs de y-as</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Roteert objecten per r graden langs de z-as</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Testobjecten maken</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Informatie over het geselecteerde element opvragen. Als een rand is geselecteerd, dan wordt de lengte ervan geretourneerd, als een cirkel, dan de diameter, als een punt, dan zijn coördinaten, als een gezicht, dan zijn afmetingen.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>longueur </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Diameter: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Afmetingen: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>Niets geselecteerd</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Met groepen</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Als ten minste één object van een groep is geselecteerd, dan zullen alle tools van deze werkbank worden toegepast op de hele groep. Als alle geselecteerde objecten in dezelfde groep staan, dan zullen alle tools van deze werkbank alleen worden toegepast op de geselecteerde objecten. Groepen zijn objecten, linkgroep, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Alleen lokaal</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Alle gereedschappen van deze werkbank zullen lokaal op objecten worden toegepast, ongeacht of ze tot groepen behoren. Groepen zijn objecten, linkgroep, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Lokaal/Groep</translation>
    </message>
  </context>
</TS>
