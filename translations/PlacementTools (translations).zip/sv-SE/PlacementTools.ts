<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv-SE" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Justerar objekt till vänster</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Justerar objekt till höger</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Justerar objekt till framsidan</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Justerar objekt baktill</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Justerar objekt till botten</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Justerar objekt till toppen</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Justerar objekt till mitten av x-axeln</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Justerar objekt till mitten av y-axeln</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Justerar objekt till mitten av z-axeln</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Positioner objekt till höger om det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Positioner objekt till vänster om det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Positioner objekt till baksidan av det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Positioner objekt till framsidan av det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Positioner objekt till över av det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Positioner objekt till undersidan av det senast valda objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Centrerar objekt mellan de två sista markerade objekten längs x-axeln</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Centrerar objekt mellan de två sista markerade objekten längs y-axeln</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Centrerar objekt mellan de två sista utvalda objekten längs z-axeln</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Flytta</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Rotation</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Standart</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Verktyg</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Flyttar de markerade objekten med ett avstånd av dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Flyttar de markerade objekten med ett avstånd av dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Flyttar de markerade objekten med ett avstånd av dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Punkt till punkt verktyg. Flyttar det näst sista markerade objektet till den sista, anpassa de valda punkterna på dessa objekt. Andra markerade objekt kommer att följa samma väg som den näst sista en. Om en kant väljs istället för en punkt så kommer mitten av kanten att tas. Om en yta väljs kommer dess geometriska centrum att tas.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Punkt att peka verktyg. Flyttar endast på x-axeln</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Punkt för att peka verktyg. Flyttar endast på y-axeln</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Punkt för att peka verktyg. Flyttar endast på z-axeln</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Standart Transform kommando</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Roterar objekt 90 grader längs x-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Roterar objekt 90 grader längs y-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Roterar objekt 90 grader längs z-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Roterar objekt -90 grader längs x-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Roterar objekt -90 grader längs y-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Roterar objekt -90 grader längs z-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Roterar objekt med r grader längs x-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Roterar objekt med r grader längs y-axeln</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Roterar objekt med r grader längs z-axeln</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Skapa testobjekt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Begär information om det valda elementet. Om en kant väljs så returneras dess längd, om en cirkel, sedan dess diameter, om en punkt, sedan dess koordinater, om ett ansikte, då dess dimensioner.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>Längd </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Diameter: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Dimensioner: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>inget valt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Med grupper</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Om minst ett objekt i en grupp väljs, kommer alla verktyg i denna arbetsbänk att tillämpas på hela gruppen. Om alla markerade objekt är inom samma grupp, kommer alla verktyg i denna arbetsbänk endast att tillämpas på de markerade objekten. Grupper är objekt Part, Link Group, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Endast lokalt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Alla verktyg i denna arbetsbänk kommer att tillämpas på objekt lokalt, oavsett om de tillhör grupper. Grupper är objekt Part, Link Group, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Lokal/grupp</translation>
    </message>
  </context>
</TS>
