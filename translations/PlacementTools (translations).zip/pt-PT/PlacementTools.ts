<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt-PT" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Alinha objetos à esquerda</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Alinha objetos à direita</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Alinha objetos na frente</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Alinha objetos para trás</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Alinha objetos para baixo</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Alinha objetos ao topo</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Alinha objetos ao centro do eixo x</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Alinha objetos ao centro do eixo y</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Alinha objetos ao centro do eixo z-</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Posições objetos à direita do último objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Posições objetos à esquerda do último objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Posições objetos para trás do último objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Posições objetos na frente do último objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Objetos de posições para o final do objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Objetos de posições abaixo do último objeto selecionado</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Centraliza objetos entre os últimos dois objetos selecionados ao longo do eixo x</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Centraliza objetos entre os dois últimos objetos selecionados ao longo do eixo y</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Centraliza objetos entre os últimos dois objetos selecionados ao longo do eixo z-</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Mover-se</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Rotação</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Padre</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Ferramentas</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Move os objetos selecionados por uma distância de dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Move os objetos selecionados por uma distância de dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Move os objetos selecionados por uma distância de dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Ponto para apontar a ferramenta. Move o penúltimo objeto selecionado para o último selecionado, alinhando os pontos selecionados nesses objetos. Outros objetos selecionados seguirão o mesmo caminho do penultimate um. Se uma aresta é selecionada em vez de um ponto, então o centro da aresta será tomado. Se for selecionada uma superfície, então o seu centro geométrico será tomado.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Ponto de ponto de ferramenta. Move somente no eixo x</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Ponto de ponto de ferramenta. Move apenas no eixo y</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Ponto da ferramenta. Se move somente no eixo z-</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Comando de Transformação Padrão</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Rotaciona os objetos 90 graus ao longo do eixo x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Rotaciona objetos 90 graus ao longo do eixo y</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Rotaciona objetos 90 graus ao longo do eixo z</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Rotaciona objetos -90 graus ao longo do eixo x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Rotaciona objetos -90 graus ao longo do eixo y</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Rotaciona objetos -90 graus ao longo do eixo z</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Rotaciona objetos por graus ao longo do eixo x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Rotaciona objetos em graus ao longo do eixo y</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Rotaciona objetos em graus ao longo do eixo z-</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Criar objetos de teste</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Solicitar informações sobre o elemento selecionado. Se uma aresta é selecionada, então seu comprimento retorna, se um círculo, então seu diâmetro, se um ponto, então as suas coordenações, se um rosto, então as suas dimensões.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>Comprimento </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Diâmetro: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Dimensões: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>nada selecionado</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Com grupos</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Se pelo menos um objeto de um grupo for selecionado, todas as ferramentas desta bancada serão aplicadas a todo o grupo. Se todos os objetos selecionados estiverem dentro do mesmo grupo, todas as ferramentas desta bancada serão aplicadas somente aos objetos selecionados. Grupos são objetos Parte, Grupo de Link, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Apenas local</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Todas as ferramentas desta bancada serão aplicadas aos objetos localmente, independentemente de pertencerem a grupos. Os grupos são objetos Parte, Grupo Link, etc.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Local/Grupo</translation>
    </message>
  </context>
</TS>
