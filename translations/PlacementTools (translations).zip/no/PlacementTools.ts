<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="no" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Justerer objekter mot venstre</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Juster objekter til høyre</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Justerer objekter mot forsiden</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Justerer objekter mot baksiden</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Justerer objekter mot bunnen</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Justerer objekter mot toppen</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Justerer objekter mot midten av x-aksen</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Justerer objekter mot midten av y-aksen</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Justerer objekter mot midten av z-aksen</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Posisjonerer objekter til høyre for det sist valgte objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Posisjonerer objekter til venstre for siste valgte objekt</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Stiller objekter til baksiden av det sist valgte objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Posisjonerer objekter til forsiden av det sist valgte objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Posisjonerer objekter til den siste delen av det merkede objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Posisjonerer objekter til under det sist merkede objektet</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Midtstiller objekter mellom de to siste valgte objektene langs x-aksen</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Midtstiller objekter mellom de to siste valgte objektene langs y-aksen</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Midtstiller objekter mellom de to siste valgte objektene langs z-aksen</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Flytt</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Rotasjon</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Stående</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Verktøy</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Flytter de merkede objektene med en avstand til dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Flytter de merkede objektene med en avstand til dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Flytter de merkede objektene med en avstand til dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Punkt til punktverktøy. Flytter det valgte objektet til den sist valgte objektet og endrer de valgte punktene på disse objektene. Andre valgte objekter vil følge samme bane som penultimate et. Hvis en kant er valgt i stedet for et punkt, tas midtpunktet av kanten. Hvis en overflate er valgt, tas geometrisk midtpunkt.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Punkt til punkt verktøy. Flytter bare på x-aksen</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Punkt til punkt verktøy. Flytter bare på y-aksen</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Punkt til punkt verktøy. Flytter bare på z-aksen</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Standart transformering kommando</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Roterer objekter 90 grader langs x-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Roterer objekter 90 grader langs y-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Roterer objekter 90 grader langs z-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Roterer objekter -90 grader langs x-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Roterer objekter -90 grader langs y-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Roterer objekter -90 grader langs z-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Roterer objekter etter r grader langs x-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Roterer objekter etter r grader langs y-aksen</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Roterer objekter etter r grader langs z-aksen</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Opprett testobjekter</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Be om informasjon om det valgte elementet. Hvis en kant er valgt, returneres lengden på den hvis en sirkel er så diameter, hvis et poeng, da koordinatene deres, hvis et ansikt, dimensjonene er dimensjoner.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>Lengde </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Diameter: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Mål: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>ingenting er valgt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Med grupper</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Hvis minst ett objekt i en gruppe er valgt, vil alle verktøyene i denne arbeidsbenken brukes på hele gruppen. Hvis alle valgte objekter er innenfor samme gruppe, vil alle verktøyene i denne arbeidsbenken bare brukes på de valgte objektene. Grupper er objekter, lenkegruppe, osv.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Kun lokalt</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Alle verktøyene til denne arbeidsbenken vil bli brukt på objekter lokalt, uansett om de tilhører grupper. Grupper er objekter, lenkegruppe osv.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Lokal/gruppe</translation>
    </message>
  </context>
</TS>
