<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el" sourcelanguage="en">
  <context>
    <name>PlacementTools</name>
    <message>
      <location filename="Align.py" line="42"/>
      <source>Aligns objects to the left</source>
      <translation>Στοίχιση αντικειμένων προς τα αριστερά</translation>
    </message>
    <message>
      <location filename="Align.py" line="70"/>
      <source>Aligns objects to the right</source>
      <translation>Στοίχιση αντικειμένων στα δεξιά</translation>
    </message>
    <message>
      <location filename="Align.py" line="98"/>
      <source>Aligns objects to the front</source>
      <translation>Στοίχιση αντικειμένων μπροστά</translation>
    </message>
    <message>
      <location filename="Align.py" line="126"/>
      <source>Aligns objects to the back</source>
      <translation>Στοίχιση αντικειμένων στο πίσω μέρος</translation>
    </message>
    <message>
      <location filename="Align.py" line="155"/>
      <source>Aligns objects to the bottom</source>
      <translation>Στοίχιση αντικειμένων στο κάτω μέρος</translation>
    </message>
    <message>
      <location filename="Align.py" line="183"/>
      <source>Aligns objects to the top</source>
      <translation>Στοίχιση αντικειμένων στην κορυφή</translation>
    </message>
    <message>
      <location filename="Align.py" line="210"/>
      <source>Aligns objects to the center of the x-axis</source>
      <translation>Ευθυγραμμίζει τα αντικείμενα στο κέντρο του άξονα X</translation>
    </message>
    <message>
      <location filename="Align.py" line="243"/>
      <source>Aligns objects to the center of the y-axis</source>
      <translation>Ευθυγραμμίζει τα αντικείμενα στο κέντρο του άξονα y-</translation>
    </message>
    <message>
      <location filename="Align.py" line="276"/>
      <source>Aligns objects to the center of the z-axis</source>
      <translation>Ευθυγραμμίζει τα αντικείμενα στο κέντρο του άξονα z-</translation>
    </message>
    <message>
      <location filename="Align.py" line="309"/>
      <source>Positions objects to the right of the last selected object</source>
      <translation>Θέσεις αντικείμενα στα δεξιά του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="342"/>
      <source>Positions objects to the left of the last selected object</source>
      <translation>Θέσεις αντικείμενα στα αριστερά του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="376"/>
      <source>Positions objects to the behind of the last selected object</source>
      <translation>Θέσεις αντικείμενα στο πίσω μέρος του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="409"/>
      <source>Positions objects to the front of the last selected object</source>
      <translation>Θέσεις αντικείμενα στο μπροστινό μέρος του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="443"/>
      <source>Positions objects to the over of the last selected object</source>
      <translation>Θέσεις αντικείμενα στο πάνω μέρος του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="476"/>
      <source>Positions objects to the under of the last selected object</source>
      <translation>Θέσεις αντικείμενα στο κάτω μέρος του τελευταίου επιλεγμένου αντικειμένου</translation>
    </message>
    <message>
      <location filename="Align.py" line="510"/>
      <source>Centers objects between the last two selected objects along the x-axis</source>
      <translation>Κέντρα αντικειμένων μεταξύ των δύο τελευταίων επιλεγμένων αντικειμένων κατά μήκος του άξονα x</translation>
    </message>
    <message>
      <location filename="Align.py" line="546"/>
      <source>Centers objects between the last two selected objects along the y-axis</source>
      <translation>Κέντρα αντικειμένων μεταξύ των δύο τελευταίων επιλεγμένων αντικειμένων κατά μήκος του άξονα y-</translation>
    </message>
    <message>
      <location filename="Align.py" line="582"/>
      <source>Centers objects between the last two selected objects along the z-axis</source>
      <translation>Κέντρα αντικειμένων μεταξύ των δύο τελευταίων επιλεγμένων αντικειμένων κατά μήκος του άξονα z-</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="41"/>
      <source>Align</source>
      <translation>Align</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="43"/>
      <source>Move</source>
      <translation>Μετακίνηση</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="45"/>
      <source>Rotation</source>
      <translation>Περιστροφή</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="47"/>
      <source>Standart</source>
      <translation>Πρότυπα</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Tools</source>
      <translation>Εργαλεία</translation>
    </message>
    <message>
      <location filename="Move.py" line="175"/>
      <source>Moves the selected objects by a distance of  dX</source>
      <translation>Μετακινεί τα επιλεγμένα αντικείμενα από απόσταση dX</translation>
    </message>
    <message>
      <location filename="Move.py" line="188"/>
      <source>Moves the selected objects by a distance of  dY</source>
      <translation>Μετακινεί τα επιλεγμένα αντικείμενα από απόσταση dY</translation>
    </message>
    <message>
      <location filename="Move.py" line="201"/>
      <source>Moves the selected objects by a distance of  dZ</source>
      <translation>Μετακινεί τα επιλεγμένα αντικείμενα κατά απόσταση dZ</translation>
    </message>
    <message>
      <location filename="Move.py" line="214"/>
      <source>Point to point tool. Moves the penultimate selected object to the last selected one, aligning the selected points on these objects. Other selected objects will follow the same path as the penultimate one. If an edge is selected instead of a point, then the center of the edge will be taken. If a surface is selected, then its geometric center will be taken.</source>
      <translation>Από σημείο σε σημείο. Μετακινεί το προτελευταίο επιλεγμένο αντικείμενο στο τελευταίο επιλεγμένο, ευθυγραμμίζοντας τα επιλεγμένα σημεία σε αυτά τα αντικείμενα. Άλλα επιλεγμένα αντικείμενα θα ακολουθήσουν την ίδια διαδρομή με το προτελευταίο αντικείμενο. Αν επιλεγεί μια ακμή αντί για ένα σημείο, τότε θα ληφθεί το κέντρο της ακμής. Εάν επιλεγεί μια επιφάνεια, τότε θα ληφθεί το γεωμετρικό κέντρο της.</translation>
    </message>
    <message>
      <location filename="Move.py" line="264"/>
      <source>Point to point tool. Moves only on the x-axis</source>
      <translation>Σημείο στο εργαλείο. Μετακινείται μόνο στον άξονα x</translation>
    </message>
    <message>
      <location filename="Move.py" line="272"/>
      <source>Point to point tool. Moves only on the y-axis</source>
      <translation>Σημείο στο εργαλείο. Μετακινείται μόνο στον άξονα y-</translation>
    </message>
    <message>
      <location filename="Move.py" line="280"/>
      <source>Point to point tool. Moves only on the z-axis</source>
      <translation>Σημείο στο εργαλείο. Μετακινείται μόνο στον άξονα z-</translation>
    </message>
    <message>
      <location filename="Move.py" line="289"/>
      <source>Standart Transform command</source>
      <translation>Εντολή κανονικού μετασχηματισμού</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="63"/>
      <source>Rotates objects 90 degrees along the x-axis</source>
      <translation>Περιστρέφει αντικείμενα 90 μοίρες κατά μήκος του άξονα x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="77"/>
      <source>Rotates objects 90 degrees along the y-axis</source>
      <translation>Περιστρέφει αντικείμενα 90 μοίρες κατά μήκος του άξονα y-</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="91"/>
      <source>Rotates objects 90 degrees along the z-axis</source>
      <translation>Περιστρέφει αντικείμενα 90 μοίρες κατά μήκος του άξονα z-</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="105"/>
      <source>Rotates objects -90 degrees along the x-axis</source>
      <translation>Περιστρέφει αντικείμενα -90 μοίρες κατά μήκος του άξονα x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="118"/>
      <source>Rotates objects -90 degrees along the y-axis</source>
      <translation>Περιστρέφει αντικείμενα -90 μοίρες κατά μήκος του άξονα y-</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="131"/>
      <source>Rotates objects -90 degrees along the z-axis</source>
      <translation>Περιστρέφει αντικείμενα -90 μοίρες κατά μήκος του άξονα z-</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="144"/>
      <source>Rotates objects by r degrees along the x-axis</source>
      <translation>Περιστροφή αντικειμένων κατά r μοίρες κατά μήκος του άξονα x</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="160"/>
      <source>Rotates objects by r degrees along the y-axis</source>
      <translation>Περιστροφή αντικειμένων κατά r μοίρες κατά μήκος του άξονα y-</translation>
    </message>
    <message>
      <location filename="Rotation.py" line="176"/>
      <source>Rotates objects by r degrees along the z-axis</source>
      <translation>Περιστρέφει τα αντικείμενα κατά μήκος του άξονα z-</translation>
    </message>
    <message>
      <location filename="Tools.py" line="21"/>
      <source>Create test objects</source>
      <translation>Δημιουργία δοκιμαστικών αντικειμένων</translation>
    </message>
    <message>
      <location filename="Tools.py" line="49"/>
      <source>Request information about the selected element. If an edge is selected, then its length is returned, if a circle, then its diameter, if a point, then its coordinates, if a face, then its dimensions.</source>
      <translation>Αίτηση πληροφοριών σχετικά με το επιλεγμένο στοιχείο. Αν επιλεγεί μια ακμή, τότε επιστρέφεται το μήκος της, αν ένας κύκλος, τότε η διάμετρος της, αν ένα σημείο, τότε οι συντεταγμένες του, αν ένα πρόσωπο, τότε οι διαστάσεις του.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="56"/>
      <source>Length </source>
      <translation>Μήκος </translation>
    </message>
    <message>
      <location filename="Tools.py" line="58"/>
      <source>Diameter: </source>
      <translation>Διάμετρος: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="60"/>
      <source>Dimensions: </source>
      <translation>Διαστάσεις: </translation>
    </message>
    <message>
      <location filename="Tools.py" line="63"/>
      <source>nothing selected</source>
      <translation>τίποτα δεν έχει επιλεγεί</translation>
    </message>
    <message>
      <location filename="Tools.py" line="77"/>
      <source>With groups</source>
      <translation>Με ομάδες</translation>
    </message>
    <message>
      <location filename="Tools.py" line="83"/>
      <source>If at least one object of a group is selected, then all the tools of this workbench will be applied to the entire group. If all selected objects are within the same group, then all tools of this workbench will be applied only to the selected objects. Groups are objects Part, Link Group, etc.</source>
      <translation>Αν επιλεγεί τουλάχιστον ένα αντικείμενο μιας ομάδας, τότε όλα τα εργαλεία αυτού του πάγκου εργασίας θα εφαρμοστούν σε ολόκληρη την ομάδα. Αν όλα τα επιλεγμένα αντικείμενα ανήκουν στην ίδια ομάδα, τότε όλα τα εργαλεία αυτού του πάγκου εργασίας θα εφαρμοστούν μόνο στα επιλεγμένα αντικείμενα. Οι ομάδες είναι αντικείμενα Μέρος, ομάδα συνδέσεων, κ.λπ.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="89"/>
      <source>Local only</source>
      <translation>Τοπικό μόνο</translation>
    </message>
    <message>
      <location filename="Tools.py" line="93"/>
      <source>All tools of this workbench will be applied to objects locally, regardless of whether they belong to groups. Groups are objects Part, Link Group, etc.</source>
      <translation>Όλα τα εργαλεία αυτού του πάγκου εργασίας θα εφαρμοστούν σε αντικείμενα τοπικά, ανεξάρτητα από το αν ανήκουν σε ομάδες. Οι ομάδες είναι μέρος αντικειμένων, ομάδα συνδέσεων κλπ.</translation>
    </message>
    <message>
      <location filename="Tools.py" line="99"/>
      <source>Local/Group</source>
      <translation>Τοπική/Ομάδα</translation>
    </message>
  </context>
</TS>
